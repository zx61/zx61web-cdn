import{b as e}from"./chunk-00cfcf60.js";import{f as r}from"./chunk-ad293b71.js";const a=r({__name:"index",setup(n){return e(),(o,t)=>null}});export{a as default};
