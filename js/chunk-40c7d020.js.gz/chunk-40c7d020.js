import{e}from"./chunk-a0f4f340.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
