import{e}from"./chunk-d0254817.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
