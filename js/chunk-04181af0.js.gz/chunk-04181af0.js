import{e}from"./chunk-81e0ac9d.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
