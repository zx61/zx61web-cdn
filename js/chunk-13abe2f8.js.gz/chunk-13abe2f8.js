import{e}from"./chunk-1be6f787.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
