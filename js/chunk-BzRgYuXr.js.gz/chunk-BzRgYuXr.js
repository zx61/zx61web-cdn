import{d as e}from"./chunk-BtNdwCXR.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
