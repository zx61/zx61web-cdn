import{f as e}from"./chunk-bc202244.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
