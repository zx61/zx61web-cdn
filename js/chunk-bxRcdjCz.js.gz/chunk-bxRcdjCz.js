import{d as e}from"./chunk-bN8bH30D.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
