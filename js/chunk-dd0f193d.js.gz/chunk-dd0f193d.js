import{a_ as e}from"./chunk-8e5325a7.js";const t={},o=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(o);export{o as n,a as r};
