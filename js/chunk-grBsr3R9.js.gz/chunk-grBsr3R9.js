import{_ as e}from"./chunk-C75s7IFO.js";const r={};function c(n,t){return"2222"}const o=e(r,[["render",c]]);export{o as default};
