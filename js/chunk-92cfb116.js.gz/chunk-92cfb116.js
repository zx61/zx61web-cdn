const n="/png/chunk-fe3b6ec9.png";export{n as _};
