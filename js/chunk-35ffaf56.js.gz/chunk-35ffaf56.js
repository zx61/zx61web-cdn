import{bC as e}from"./chunk-ad293b71.js";const t={},o=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),n=e(o);export{o as n,n as r};
