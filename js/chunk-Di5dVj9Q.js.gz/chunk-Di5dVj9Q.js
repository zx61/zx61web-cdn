const n="/png/chunk-CwDhm95Y.png";export{n as _};
