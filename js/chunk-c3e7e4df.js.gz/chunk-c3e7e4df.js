import{f as e}from"./chunk-9e80d102.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
