import{e}from"./chunk-f1eab420.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
