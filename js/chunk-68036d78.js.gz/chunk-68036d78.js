import{e}from"./chunk-5adf69d9.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
