import{_ as e}from"./chunk-a0327024.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
