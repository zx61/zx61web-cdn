import{f as e}from"./chunk-0e7a2c01.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
