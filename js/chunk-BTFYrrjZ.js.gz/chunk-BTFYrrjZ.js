import{d as e}from"./chunk-DP0Z30vw.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
