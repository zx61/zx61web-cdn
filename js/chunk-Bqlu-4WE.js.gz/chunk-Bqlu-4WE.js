import{_ as e}from"./chunk-CiXiLY6i.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
