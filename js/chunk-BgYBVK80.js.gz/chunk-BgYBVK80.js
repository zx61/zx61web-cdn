import{_ as e}from"./chunk-bN8bH30D.js";const r={};function c(n,t){return"2222"}const o=e(r,[["render",c]]);export{o as default};
