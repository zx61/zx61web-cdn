import{_ as e}from"./chunk-a0327024.js";const r={};function c(n,t){return"2222"}const o=e(r,[["render",c]]);export{o as default};
