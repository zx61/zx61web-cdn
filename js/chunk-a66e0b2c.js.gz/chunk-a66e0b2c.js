import{e}from"./chunk-5b0306a6.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
