import{_ as e}from"./chunk-DumNPkiB.js";const r={};function c(n,t){return"2222"}const o=e(r,[["render",c]]);export{o as default};
