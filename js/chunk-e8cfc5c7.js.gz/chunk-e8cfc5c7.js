import{e}from"./chunk-01e6aca6.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
