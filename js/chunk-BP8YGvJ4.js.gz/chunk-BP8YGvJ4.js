import{_ as e}from"./chunk-DumNPkiB.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
