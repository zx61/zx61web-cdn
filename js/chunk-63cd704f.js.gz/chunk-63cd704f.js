import{f as e}from"./chunk-d7c045dd.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
