import{d as e}from"./chunk-CTl_Mh-K.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
