import{_ as e}from"./chunk-DP0Z30vw.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
