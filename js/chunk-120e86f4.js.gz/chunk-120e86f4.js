import{f as e}from"./chunk-a4353a9b.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
