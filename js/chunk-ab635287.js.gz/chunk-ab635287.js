import{e}from"./chunk-4aa116ce.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
