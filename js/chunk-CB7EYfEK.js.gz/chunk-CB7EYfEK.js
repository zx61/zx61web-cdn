import{_ as e}from"./chunk-CTl_Mh-K.js";const r={};function c(n,t){return"2222"}const o=e(r,[["render",c]]);export{o as default};
