import{d as e,C as n}from"./chunk-a0327024.js";const _=e({__name:"index",setup(r){return n(),(s,t)=>null}});export{_ as default};
