import{e}from"./chunk-3bf654cb.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
