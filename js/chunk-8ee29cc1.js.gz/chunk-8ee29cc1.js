import{e}from"./chunk-c4e2faa5.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
