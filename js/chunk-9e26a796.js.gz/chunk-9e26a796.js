import{_ as e}from"./chunk-0f9d6c2a.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
