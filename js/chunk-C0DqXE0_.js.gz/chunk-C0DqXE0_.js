import{_ as e}from"./chunk-CTl_Mh-K.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
