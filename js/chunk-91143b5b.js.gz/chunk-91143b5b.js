import{e}from"./chunk-55170621.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
