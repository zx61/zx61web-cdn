import{a_ as e}from"./chunk-5be45be0.js";const t={},o=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(o);export{o as n,a as r};
