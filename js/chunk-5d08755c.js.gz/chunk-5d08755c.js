import{e}from"./chunk-1a3357b8.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
