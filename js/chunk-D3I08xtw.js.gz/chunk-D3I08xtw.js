import{cu as e}from"./chunk-D0fr2S5m.js";const t={},r=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(r);export{a as r};
