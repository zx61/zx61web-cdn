import{_ as e}from"./chunk-Czqc0dE8.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
