import{d as e,o as n,c as o}from"./chunk-DumNPkiB.js";const s=e({__name:"index",setup(t){return(a,c)=>(n(),o("div"))}});export{s as default};
