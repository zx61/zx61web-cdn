import{d as e,C as n}from"./chunk-0f9d6c2a.js";const _=e({__name:"index",setup(r){return n(),(s,t)=>null}});export{_ as default};
