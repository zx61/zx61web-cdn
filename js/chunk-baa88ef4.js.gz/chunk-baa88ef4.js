import{f as e}from"./chunk-76a20865.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
