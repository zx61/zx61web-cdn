import{_ as e}from"./chunk-1a3357b8.js";const r={};function c(n,t){return"自动识别 abi名 参数数量/类型 参数值示例 返回值类型解析"}const o=e(r,[["render",c]]);export{o as default};
