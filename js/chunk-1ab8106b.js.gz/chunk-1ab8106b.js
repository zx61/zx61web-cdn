import{e}from"./chunk-18c3e320.js";const o=e({__name:"index",setup(n){return(t,r)=>null}});export{o as default};
