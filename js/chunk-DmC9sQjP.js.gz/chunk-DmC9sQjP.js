import{_ as e}from"./chunk-C75s7IFO.js";const r={};function t(c,n){return"wait"}const o=e(r,[["render",t]]);export{o as default};
