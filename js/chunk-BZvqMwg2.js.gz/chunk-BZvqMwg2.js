import{_ as e}from"./chunk-D0fr2S5m.js";const r={};function c(n,t){return"2222"}const o=e(r,[["render",c]]);export{o as default};
